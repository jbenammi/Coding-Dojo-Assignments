from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def default():
    return render_template("default.html")

@app.route('/ninja/<name>')
@app.route('/ninja/')
def ninja(name="all"):

    turtles = {
        'blue': "leonardo.jpg",
        'orange': "michelangelo.jpg",
        'purple' : "donatello.jpg",
        'red' : "raphael.jpg",
        'all' : "tmnt.png",
        'hack' : "notapril.jpg"
    }

    if name == "blue":
        name = turtles['blue']
    elif name == "orange":
        name = turtles['orange']
    elif name == "purple":
        name = turtles['purple']
    elif name == "red":
        name = turtles['red']
    elif name == "all":
        name = turtles['all']
    else:
        name = turtles['hack']

    return render_template("ninja.html", name=name)
app.run(debug=True)
