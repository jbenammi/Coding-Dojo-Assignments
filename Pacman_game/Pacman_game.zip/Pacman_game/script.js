$(document).ready(function () {
    console.log("j@uery on tap");
}); 