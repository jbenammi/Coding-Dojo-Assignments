from flask import Flask, render_template, request, redirect, session, flash
import re
from datetime import datetime
app = Flask(__name__)
app.secret_key = "134987"

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
PASS_REGEX = re.compile(r"^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$")


@app.route('/')
def index():
    return render_template("index.html")

def hasNumbers(inputString):
	return any(char.isdigit() for char in inputString)

def birthday(birthday):
	dateObj = datetime.strptime(birthday, '%Y-%m-%d')
	current_year = datetime.now().year

	print(dateObj.year)
	print(current_year)

	if int(current_year) < int(dateObj.year):
		return True
	else:
		return False

@app.route('/result', methods=['GET', 'POST'])
def result():
	if (request.method == "POST"):

		session['first_name'] = request.form['first_name']
		session['last_name'] = request.form['last_name']
		session['birthday'] = request.form['birthday']
		session['email'] = request.form['email']
		session['password'] = request.form['password']
		session['confirm_pass'] = request.form['confirm_pass']


		if len(session['first_name']) < 1:
			flash("First name can't be empty")

		elif hasNumbers(session['first_name']):
			flash("Name can't contain a number")

		elif len(session['last_name']) < 1:
			flash("Last name can't be empty")

		elif birthday(session['birthday']):
			flash("Invalid Date, should be in the past")

		elif hasNumbers(session['last_name']):
			flash("Surname cant contain a number")

		elif len(session['email']) < 1:
			flash("Email can't be empty")

		elif not EMAIL_REGEX.match(session['email']):
			flash("Email invalid")

		elif len(session['password']) < 1:
			flash("Password can't be empty")

		elif not PASS_REGEX.match(session['password']):
			flash("Password must be: Minimum 8 characters at least 1 Alphabet, 1 Number and 1 Special Character")

		elif len(session['password']) < 8 and len(session['password']) > 1 :
			flash("Password need to be more than 8 characters")

		elif len(session['confirm_pass']) < 1:
			flash("Password Confirm can't be empty")

		elif session['confirm_pass'] != session['password']:
			flash("Password must match")

		else:
			flash("Success. Thank you for submitting your information!")
		return redirect('/')
app.run(debug=True)
