from datetime import datetime
from flask import Flask, render_template, request, redirect, session
import random
import sys

app = Flask(__name__)
app.secret_key = '9877698rewt'

def setGold():
    session['gold'] = 0
    session['message'] = []

@app.route('/', methods=['GET', 'POST'])
def index():

    try:
        session['gold']
        session['message']

    except:
        setGold()
    try:
        if 'farm' in request.form:
            rand = random.randrange(10,21)
            session['gold'] += rand
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            session['message'].append("Earned {} gold from the farm!  ({})".format(rand, now))
        elif 'cave' in request.form:
            rand = random.randrange(5,11)
            session['gold'] += rand
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            session['message'].append("Earned {} gold from the cave!  ({})".format(rand, now))
        elif 'house' in request.form:
            rand = random.randrange(2,6)
            session['gold'] += rand
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            session['message'].append("Earned {} gold from the house!  ({})".format(rand, now))
        elif 'casino' in request.form:
            winLose = random.randrange(1,3)
            if winLose == 1:
                rand = random.randrange(0,51)
                session['gold'] += rand
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                session['message'].append("Won {} gold from the casino!  ({})".format(rand, now))
            else:
                rand = random.randrange(0,51)
                session['gold'] -= rand
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                session['message'].append("Lost {} gold from the casino!  ({})".format(rand, now))
        session['mesLength'] = len(session['message'])
    except:
        print (request.form)

    return render_template('index.html')

app.run(debug=True)
